//Shape* -> This reffers to the a pointer to a object of class shape; Now assuming that Shape is a base class and we have classes: Point, Circle, and Line that derive
//from class shape then we can have a pointer that points to a shape class object point to an object of class type: Point, Circle or Line since they derive from the Shape class
//If we have multiple dervied classes then the compiler might not know which class type our pointer is pointing to; it could in our case point to a Shape class object,
//Point, Circle or Line. As a result, we make functions virtual; By making functions virtual we ensure that the compiler chooses the correct function in the proper class
//For ex: If we have shape* = point class object; And then we write *shape.ToString(). Then the compiler make sure that it acesses the ToString() function within the Point class as long as we labeled the function as virtual
//All we need to do is use the virtual keyword for the given function in the base class and that's it. If we want polymorphism to be enacted on all functions then we use the virtual keyword on all the functions in the base class
//If the virtual keyword is not inputted then the function in the base class takes priority/get executed by the compiler.
//Each classes function are independent to eachother
//fun1() and fun1(x) are considered to be 2 different functions. One has a parameter and the other doesn't

//The inheritance : syntax is done in the header file of the derived class; Derived class : Base class

//Runtime polymoprhism is achieved only through a base class pointer which could point to an object of type base class or an object of any of time inherting classes

//Inheritance = Access granted/given

//Because ToString() is not virtual function in the base class takes priority; This is strictly when dealing with pointers that points to object of base class type

#include "Shape.h"
#include "Point.h"
#include "Line.h"
#include "Circle.h"
#include <iostream>
#include <sstream>
#include <string>
using namespace std;

//namespace directive
using namespace Filip::CAD;

int main() {

	Shape s;
	Point p1(10, 20);
	Point p2(2, 3);
	//Line l1(Point w(1,3), Point u(4,3)); I get an error for some reason when trying to create a Line class object in this notation
	Line l1(p1, p2);

	//std::cout << s.ToString() << std::endl;
	//std::cout << p1.ToString() << std::endl; //Here we are simply acessing the ToString() functionin the Point class since p1 is an object of Point type; Nothing else just conventional . operator usage

	//std::cout << l1.ToString() << std::endl;

	//Testing Inheritance
	//std::cout << "Shape ID: " << s.ID(); //This works
	//std::cout << "Point ID: " << p1.ID() << std::endl; //Works since the Point class inherits from the Shape() class, the Point class can acess the public members of the Shape class
	//std::cout << "Line ID: " << l1.ID() << std::endl; //Works as well same idea as the above

	Shape* sp; //Pointer to an object of type base class
	sp = &p1; //ToString() from the Shape class is executed; Our pointer points to an object of type Point class; This pointer could point to an object of type base class, of any object of type derived class; Yes this is possible
	//std::cout << sp->ToString(); //Because ToString() is not a virtual function the ToString() in the base class takes precedence despite the fact that the pointer points to an object of Point class(a derived class). Point class derives from the Shape class. So ID: random number which is handed for the value of m_id
	//If ToString() is a virtual function then it would print the ToString() function in the Point Class aka the derived class if ToString() is not declared virtual in the base class then the ToString() function in the base class will run - Polymorphism + virtual functions

	Point p3;
	p3 = p1; //Testing the = operator
	//std::cout << p1 << "," << p3.ID() << std::endl; 
	//std::cout << p3 << "," << p3.ID() << std::endl; //<<p3 initiates the << operator function in the Point class p3.ID() fetches the ID() function in the Shape class; ID is copied

}