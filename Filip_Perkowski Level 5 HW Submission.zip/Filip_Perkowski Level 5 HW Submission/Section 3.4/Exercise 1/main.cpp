//Number of constructor calls body statement syntax vs Number of constructor calls using colon syntax
#include "Circle.h"
#include <iostream>
#include <sstream>
#include <string>

//Namespace Directive
using namespace Filip::CAD;
//Objective -> In this file we test the colon syntax(it's effectiveness) + the components of all of our classes

int main() {
	Point p1(10, 2);
	Point p2(3, 19);
	Line l; //Running this via the : syntax; We didnt use the virtual function on the Point class aka our base class hence when deleting from memory a Line class object both the Point class and Line class destructors get called
	//A Line object contains 2 Point object hence 2 Point class constructor calls(destructor + constructor is not marked virtual) + Line class constructor call for the Line object l itseld
	
	Line l2 = l; //Initiating the assignment operator
	
	//Using the : syntax the constructors the = operator is ran 1 less time than if we were to use the {} syntax; The constructor count is the same since we didn't use virtual
	

}
