#include "Point.h"
#include <iostream>
#include <sstream>
#include <string>
#include <cmath>

//Objective -> In this file we define all the components within the Point Class; Using the Colon Syntax

//Write some text within all our constuctor + deconstructor definitions so that we can test the in the main.cpp file

//Defining the constructors and Deconstructor via the Colon Syntax
namespace Filip { //Puting the .cpp in the braces of the namespaces
	namespace CAD {
		Point::Point() : m_x(0), m_y(0) {
			std::cout << "Default Constructor Point Class" << std::endl;
		}

		Point::Point(double a, double b) : m_x(a), m_y(b) {
			std::cout << "Constructor with 2 double arguments Point Class";
		}

		Point::Point(const Point& c) : m_x(c.m_x), m_y(c.m_y) {
			std::cout << "Copy Constructor Point Class" << std::endl;
		}

		Point::~Point() {
			std::cout << "Desconstructor Point Class" << std::endl;
		}

		//Get() Functions
		double Point::X() const {
			return m_x;
		}

		double Point::Y() const {
			return m_y;
		}

		//Set() Functions
		void Point::X(const double& a) {
			m_x = a;
		}

		void Point::Y(const double& b) {
			m_y = b;
		}

		//ToString() Function
		std::string Point::ToString() const {
			std::stringstream a, b;
			a << m_x, b << m_y; //Experimenting with a different notation
			std::string resi = "Point(" + a.str() + "," + b.str() + ")";
			return resi;
		}

		//Distance() Functions
		double Point::Distance() const {
			return sqrt(pow(m_x - 0, 2) + pow(m_y - 0, 2));
		}

		double Point::Distance(const Point& b) const {
			return sqrt(pow(m_x - b.m_x, 2) + pow(m_y - b.m_y, 2));
		}

		//Operator Functions
		Point Point::operator-() const {
			Point c(-m_x, -m_y); //Create a independent Point class object and return it
			return c;
		}

		Point Point::operator*(double factor) const {
			Point c(m_x * factor, m_y * factor);
			return c;
		}

		Point Point::operator+(const Point& c) const {
			Point d(m_x + c.m_x, m_y + c.m_y);
			return d;
		}

		bool Point::operator==(const Point& c) const {
			return m_x == c.m_x && m_y == c.m_y; //Expression as the return value; 
		}

		Point& Point::operator=(const Point& source) {
			if (this == &source) {
				return *this;
			}
			else {
				m_x = source.m_x;
				m_y = source.m_y;
				return *this;
			}
			std::cout << "Assignment Operator Point Class" << std::endl;
		}

		Point& Point::operator*=(double factor) {
			m_x = m_x * factor;
			m_y = m_y * factor;
			return *this;
		}
	}
}

std::ostream& operator<<(std::ostream& o, const Filip::CAD::Point& c) {
	o << c.ToString();
	return o;
}

