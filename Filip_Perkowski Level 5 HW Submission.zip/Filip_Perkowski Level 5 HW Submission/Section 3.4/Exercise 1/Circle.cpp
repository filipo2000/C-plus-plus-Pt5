#define _USE_MATH_DEFINES
#include <cmath>
#include "Circle.h"
#include <iostream>
#include <sstream>
#include <string>

//namespace directive
using namespace Filip::CAD;

//Objective -> In this file we define all the components within the Circle class

//Constructors and Deconstructor via : syntax

namespace Filip {
	namespace CAD {
		Circle::Circle() : m_point(Point(0, 0)), m_radius(10) { //Set the default radius to 10
			std::cout << "Default Constructor Circle Class!!" << std::endl;
		}

		Circle::Circle(Point a, double b) : m_point(a), m_radius(b) {
			std::cout << "Constructor holding 2 double parameters Circle Class" << std::endl;
		}

		Circle::Circle(const Circle& c) : m_point(c.m_point), m_radius(c.m_radius) {
			std::cout << "Copy Constructor Circle Class" << std::endl;
		}

		Circle::~Circle() {
			std::cout << "Deconstructor Circle Class!!" << std::endl;
		}

		//Get() Functions
		Point Circle::CentrePoint() const {
			return m_point;
		}

		double Circle::Radius() const {
			return m_radius;
		}

		//Set() Functions
		void Circle::CentrePoint(const Point& a) {
			m_point = a;
		}

		void Circle::Radius(const double& b) {
			m_radius = b;
		}

		//= operator function
		Circle& Circle::operator=(const Circle& c) {
			if (this == &c) {
				return *this;
			}
			else {
				m_point = c.m_point;
				m_radius = c.m_radius;
				return *this;
			}
			std::cout << "Assignment Operator Circle Class!!" << std::endl;
		}

		//ToString() Function
		std::string Circle::ToString() const {
			std::stringstream a, b;
			a << m_radius;
			std::string resi = "Circle with" + m_point.ToString() + "and a radius of " + a.str();
			return resi;
		}

		//Measurement Functions()
		double Circle::Area() const {
			return M_PI * pow(m_radius, 2);
		}

		double Circle::Diameter() const {
			return m_radius * 2;
		}

		double Circle::Circumfrence() const {
			return 2 * M_PI * m_radius;
		}

	}
}

//<< operator function; This function is not part of the Circle Class; No Circle::
std::ostream& operator<<(std::ostream& o, const Filip::CAD::Circle& c) {
	o << c.ToString();
	return o;
}