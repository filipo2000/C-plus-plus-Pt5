#pragma once
#ifndef ArrayException_h
#define ArrayException_h
#include "Array.h"
#include <iostream>
#include <sstream>
#include <string>

//Objective -> This is the header file for our Array Exception Class

class ArrayException {
	private:

	public:
		//Constructor and Deconstructor
		ArrayException(){}
		virtual ~ArrayException(){}
		
		//GetMessage() Function
		virtual std::string GetMessage() const = 0;


};



#endif