#pragma once
#ifndef OutOfBoundsException_h
#define OutOfBoundsException_h

#include "Array.h"
#include "ArrayException.h" //This header file inclusion is needed for proper inheritance to occur
#include <iostream>
#include <sstream>
#include <string>

//Objective -> In this file we declare all the components within the OutOfBoundsException class

class OutOfBoundsException: public ArrayException {
	private:
		int m_index;
	public:
		//Constructor and Deconstructor
		OutOfBoundsException(){}
		OutOfBoundsException(int a):m_index(a) {} //Constructor that takes in an int as an argument
		~OutOfBoundsException(){}
		
		//Get Message() Function
		std::string GetMessage() const {
			std::stringstream a;
			a << m_index;
			std::string resi = "Index:" + a.str() + "is not in range - Error";
			return resi;
		
		}





};

#endif