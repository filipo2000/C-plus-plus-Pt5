#include <iostream>
#include <sstream>
#include <string>
#include "Array.h"
#include "ArrayException.h"
#include "OutOfBoundsException.h"
#include "Shape.h"
#include "Point.h"

//Objective -> In this class we are defining all the components within the Array Class
//Implementing respective try catch block in the Array class

//Starting by defining the Constructors and Deconstructor

//namespace Directive
using namespace Filip::CAD;

namespace Filip {
	namespace Containers {
		Array::Array() {
			m_size = 10;
			m_data = new Point[m_size]; //Our pointer which points to a Point class object points to the first element of an array of pointers. The array is created and allocated on the heap via new keyword
		}

		Array::Array(int c) {
			m_size = c;
			m_data = new Point[m_size];
		}

		Array::Array(const Array& c) {
			m_size = c.m_size; //Both the underlying object and the passed in argument which is an Array class object now have the same size values and both Pointers point to the same array in the heap
			m_data = new Point[m_size];
			for (int i = 0; i < m_size; i++) {
				m_data[i] = c.m_data[i]; //We can't just copy at once it's incorrect. So using a for loop to copy the Point elements from the Array object passed in by parameter to the underlying Array object one by one using a for loop

			}

		}
		Array::~Array() {
			delete[] m_data; //By writing delete and the name of the pointer we are dealocating the pointer so the pointer that's on the stack memory is a free pointer(is not pointing to anything) and the array allocated on the heap previously when used the new keyword is now longer in the heap's memory
		}

		//Size() Function
		int Array::Size() const {
			return m_size;
		}

		//Defining the Get() and Set() Functions
		Point& Array::GetElement(int index) const {
			if (index < 0 || index >= m_size) { //Index inputted as argument is invalid
				throw OutOfBoundsException(index);
			}
			else {
				return m_data[index];
			}
		}
		void Array::SetElement(Point* p, const int index) {
			if (index >= 0 || index < m_size) {
				m_data[index] = *p;
			}
			else { //Index is not valid and so we implement our try-catch block
				throw OutOfBoundsException(index); 
			}
		}


		//Defining the = operator function; This needs work
		Array& Array::operator=(const Array& c) {
			if (this == &c) {
				return *this; //Underlying Array class object that was used to initiate this = operator function is returned
			}
			delete[] m_data; //This deallocates the array that was stored in memory. m_data is the pointer that pointed to this array. This pointer m_data is now one the stack and free to point to something else

			this->m_size = c.m_size;
			m_data = new Point[m_size]; //m_data now points to a new created array allocated on the heap. This array hold m_size(number of elements) Point class objects

			for (int i = 0; i < m_size; i++) {
				m_data[i] = c.m_data[i]; //Now pointers point to the same Point class objects
			}
			return *this;
		}


		//Defining the non-const [] operator function
		Point& Array::operator[](int index) {
			if (index < 0 || index >= m_size) { //Invalid index
				throw OutOfBoundsException(index);
			}
			else {
				return this->m_data[index];
			}

		}

		const Point& Array::operator[](int index) const {
		if (index < 0 || index >= m_size) { //Invalid index
			throw OutOfBoundsException(index);
				}
		else {
				return this->m_data[index];
			}

		}

	} //End of namespaces braces
}

