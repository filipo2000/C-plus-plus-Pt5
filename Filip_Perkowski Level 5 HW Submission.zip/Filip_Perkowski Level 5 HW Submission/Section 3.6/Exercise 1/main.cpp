#include "Shape.h"
#include "Array.h"
#include "Point.h"
#include <iostream>
#include <sstream>
#include <string>

//Objective -> Checking the Exception Handling implemented in the Array class

//When accessing an invalid error we get a compiler error hence we should implement a try block

//Namespace Directives 
using namespace Filip::Containers;
using namespace Filip::CAD;

int main() {
	Point p1(10, 3); //Create a dummy pointer to a Point object + Point object variable
	Point* ptr = &p1;

	//Try catch block
	try {
		Array a1(10);
		for (int i = 0; i != 10; i++) {
			a1.SetElement(&p1,i); 
			std::cout << a1.GetElement(i + 1) << std::endl;
		}
	}
	
	catch (int e) {
		if (e == -1) { 
			std::cout << "Invalid Index, -1 was thrown!!" << std::endl;
		}

	}

	catch (...) {
		std::cout << "Argument is not an int!!" << std::endl;
	}
}