#include "Shape.h"
#include <iostream>
#include <string>
#include <sstream>
#include <stdlib.h> //To use rand()

//Objective -> Here we define all the contents within the Shape class

//Defining our Constructors and Deconstructor
Shape::Shape() : m_id(rand()) { //Using the colon syntax 

}

Shape::Shape(int a) : m_id(a) {

}

Shape::Shape(const Shape& c) : m_id(c.m_id) {

}

Shape::~Shape() {
	//std::cout << "Deconstructor!!" << std::endl;
}

//ToString() 
std::string Shape::ToString() const {
	std::stringstream a;
	a << m_id; //m_id is yielded by using rand() -> random number generator
	std::string resi = "ID: " + a.str();
	return resi;
}

Shape& Shape::operator=(const Shape& c) {
	if (this == &c) {
		return *this;
	}
	this->m_id = c.m_id;
	return *this;
}

//Get() Function
int Shape::ID() const {
	return m_id;
}

//Print() Function
void Shape::Print() const{
	std::cout << ToString() << std::endl; //The ToString() function must be virtual for the compiler to direct to the ToString() function in the proper class
}