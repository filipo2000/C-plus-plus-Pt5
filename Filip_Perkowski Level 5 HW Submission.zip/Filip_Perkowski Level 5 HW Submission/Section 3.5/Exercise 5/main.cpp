#include "Shape.h"
#include "Point.h"
#include "Line.h"
#include "Circle.h"
#include <iostream>
#include <sstream>
#include <string>

//The Point and Line classes call the Print() class despite the fact that the Print() function is not available in the Point and Line classes due to inheritance. Aka we can use a dervied class object to acess a member of the base class

//Objective -> Here we are testing all the classes + the Print() function

//Namespace Directive
using namespace Filip::CAD;

//The Template Method is the opposite/ does the opposite to the Base Class Functionality

int main() {

	//Due to inheritance we can fetch a base class member with a derived class object; ToString() will make it so we initiate the derived class ToString() function if present

	Point p1(10, 2);
	//p1.Print(); //Works perfectly; We get directed to the ToString() function in the Point class

	Point p2(3, 10);

	Line l1(p1, p2);
	//l1.Print(); //Works perfectly

	Circle c1(p1, 4);
	//c1.Print(); //Works perfectly



	
}






























