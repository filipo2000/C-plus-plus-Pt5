#pragma once
#ifndef Point_h
#define Point_h

#include <iostream>
#include <sstream>
#include <string>
#include "Shape.h"

//Objective -> This is our header file where we declare all the components of the Point Class

namespace Filip {
	namespace CAD {
		class Point : public Shape { //Now the Point Class inherits from the Shape Class
		private:
			double m_x;
			double m_y;
		public:
			//Our constructors and deconstructor
			Point();
			Point(double a, double b);
			Point(const Point& p);
			~Point();

			//Our Get() Functions
			double X() const;
			double Y() const;

			//Our Set() Functions
			void X(const double& a);
			void Y(const double& b);


			//ToString() Function
			std::string ToString() const;

			//Distance() Functions
			double Distance() const;
			double Distance(const Point& a) const;


			//Our overlaoaded functions
			Point operator -() const;
			Point operator *(double factor) const;
			Point operator + (const Point& p) const;
			bool operator ==(const Point& p) const;
			Point& operator =(const Point& source);
			Point& operator *=(double factor);


		};

	}
}


//Our ostream << operator function outside the class but within the header file
std::ostream& operator <<(std::ostream& o, const Filip::CAD::Point& p);

#endif