//When an object is deleted/removed from memory aka terminated the deconstructor is called. In fact, when a destructor from the derived class is called the destructor from the base class is called as well;
//The same is true with the default constructors; Therefore when a object of default class type gets terminated the default constructor from the derived class gets called as well as the constructor from the base class gets called

//Objective -> Testing virtual deconstructors

#include "Shape.h"
#include "Point.h"
#include "Line.h"
#include "Circle.h"
#include <iostream>
#include <sstream>
#include <string>

//Namespace Directive
using namespace Filip::CAD;

//Difference in syntax between a pointer to an array and an array of pointers
//int (*arr)[10] -> Here arr is a pointer that points to an array of 10 ints
//int* arr[10] -> Here arr is an array of 10 pointers which point to int variables

//Keyword virtual should only be declared in the base class. Same idea when creating a pure virtual function

int main() {

	Shape* shapes[3]; //Here shapes is an array of 3 pointers which point to Shape class objects; Since the Point, Line and Circle class dervie from the Shape class a pointer that points to the Shape class can also in this case point to a Point, Line or Circle object
	shapes[0] = new Shape(); //These 3 elements are allocated on the heap since the new keyword is used; the new keyword returns a pointer
	shapes[1] = new Point();
	shapes[2] = new Line();

	//for loop
	for (int i = 0; i < 3; i++) {
		delete shapes[i]; //This will one by terminate from the heap the objects which each pointer/element in the array points to; The pointers themselves/elements of the array are allocated on the stack not on the heap
	} //Pre- Virtual -> Only the destructors of the base class are called; After making the destructor virtual -> The derived class destructors are called 

	//If we want to terminate the whole array itself at once we do delete[] shapes; Now shapes is an empty array and deleted/terminated from stack memory




}