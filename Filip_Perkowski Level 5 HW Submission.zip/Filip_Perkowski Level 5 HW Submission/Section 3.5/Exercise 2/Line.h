#pragma once
#ifndef Line_h
#define Line_h

#include <iostream>
#include <sstream>
#include <string>
#include "Point.h"
#include "Shape.h"

//Objective -> Here we declare all the components within the Line class

namespace Filip {
	namespace CAD {
		class Line : public Shape { //Now the Line class inherits from the Shape Class
		private:
			Point start;
			Point end;
		public:
			//Declaring our constructors and deconstructor
			Line();
			Line(Point a, Point b);
			Line(const Line& c);
			~Line();

			//Get() Functions
			Point P1() const;
			Point P2() const;

			//Set() Functions
			void P1(const Point& a);
			void P2(const Point& b);

			//ToString() Functions
			std::string ToString() const;

			//= operator function
			Line& operator=(const Line& p);

			//Length() Function
			double Length() const;


		};

	}
}


//operator << function; Because this function is not part/a member of the line class we declare it outside the {}; brackets
std::ostream& operator<<(std::ostream& o, const Filip::CAD::Line& c);





#endif