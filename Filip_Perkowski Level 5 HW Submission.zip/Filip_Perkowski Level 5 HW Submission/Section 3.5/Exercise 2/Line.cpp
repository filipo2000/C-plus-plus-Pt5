#include <iostream>
#include <sstream>
#include <string>
#include "Line.h"

//Objective -> This is our file where we define the contents of our Line class

//Since the Line class inherits from the Shape Class, whenever we create a Line class object we initiate the Shape default constructor

namespace Filip {
	namespace CAD {
		Line::Line() : Shape(), start(Point(0, 0)), end(Point(0, 0)) { //Using the : syntax

		}

		Line::Line(Point a, Point b) : Shape(), start(a), end(b) {

		}

		Line::Line(const Line& c) : Shape(c), start(c.start), end(c.end) { //We should make this parameter const as we won't be using c to change the arguments value. Aka c.start.X() = c.start.X() + 1; This would make the argument(the Line object) it's m_x value increase by 1. When we say see we are reffering to the argument as c is a reference

		}


		Line::~Line() {
			//std::cout << "The Deconstructor!!" << std::endl;
		}


		//Our Get() Functions
		Point Line::P1() const { //Our function returns the start Point within the Line class object
			return start;
		}

		Point Line::P2() const { //This function returns the end Point
			return end;
		}

		//Our Set() Functions
		void Line::P1(const Point& a) { //This function set the value of the start point to the value a(Point class object passed via argument when calling the object)
			start = a; //Start reffers to the start Point object component of the Line class object that uses the . operator to access this P1() function as this point in time
		}

		void Line::P2(const Point& b) { //This function sets the value of the end point to the value b
			end = b;
		}

		//ToString() Function
		std::string Line::ToString() const {
			std::stringstream a, b;
			a << " Line with Points (" << start.X() << "," << start.Y() << ")"; //Remember we can't acess private members of the Point Class here as this isin't a function from the Point class but from the Line class
			b << " , (" << end.X() << "," << end.Y() << ")";
			std::string s = Shape::ToString() + " and" + a.str() + b.str(); //We can call the ToString() from the Shape Class because we have the appropriate header files included; 
			return s;

		}

		//Overloaded = operator Function
		Line& Line::operator=(const Line& c) {
			if (this != &c) {
				start = c.start;
				end = c.end;
				return *this;
			}
			else {
				return *this;
			}

		}


		//Length() Function
		double Line::Length() const { //This function will return the distance between our start and end Point class object which make up a given Line class object; Line class object . Length() would initiate this function
			return start.Distance(end);
		}

	}
}




//Operator << function; This function is not part of the Line class hence we define it outside the {}; brackets and there's no :: resolution operator
std::ostream& operator<<(std::ostream& o, const Filip::CAD::Line& p) {
	o << p.ToString();
	return o;
}