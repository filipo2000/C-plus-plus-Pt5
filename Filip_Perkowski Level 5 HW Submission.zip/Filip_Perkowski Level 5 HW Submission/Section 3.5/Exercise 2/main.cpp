//Inheritance allows us to fetch a member of the base class using an object of derived class type
//Point class object .(. operator) name of funtion always acesses that function for us in the Point class as always. Regardless of inheritance presense or not

//Objective -> Here we are testing how derived classes can acess members of our base classes other than the base class pointer + virtual function label way

#include "Point.h"
#include "Line.h"
#include "Shape.h" //Including this header file is enough since it indirectly also include the Line header and the Line header include the Point header
#include "Circle.h"
#include <iostream>
#include <sstream>
#include <string>

//Namespace Directive
using namespace Filip::CAD;


int main() {


	Point p1(3, 1);
	Point p2(4, 8);
	std::cout << p1.ToString() << std::endl; //Could've also just done cout << p1 and initiate the << operator function and result would've been the same since the body of the << operator function calls the ToString() function
	//The ID is printed out + Point class object description

	Line l1(p1, p2);
	std::cout << l1 << std::endl; //Print out the ID alongside the description of the Line class object; Since we are using the << operator on the class obejct, this initaites the << operator function from the Line class. 
	//And doing so we fetch the ToString() function from the Line class

	Circle c1(p1, 3);
	std::cout << c1 << std::endl;



}