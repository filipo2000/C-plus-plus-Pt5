//Testing polymorphism; Function ToString() should be labeled as virtual; The virtual keyword should be applied to the appropriate function in the "base class" so in our case the Shape Class

#include "Point.h"
#include "Shape.h"
#include <iostream>
#include <sstream>
#include <string>

//Namespace Directive
using namespace Filip::CAD;

//Objective -> Here we test the polymorphism, the virtual keyword

int main() {
	
	//Adding the virtual keywordL It only needs to get added in the header file;
	//Creating a Point class object
	Point p2(10, 32);
	Shape* ptr = &p2; //A pointer that points can points to a object of type Point class since class Point class inherits from class Point
	std::cout << ptr->ToString() << std::endl; //This should call the ToString() in the Point class since our pointer points to a Point class object. If it weren't for the virtual keyword then it would run the ToString() function in the Shape class(base class) as it takes precedence since we have a Pointer to a variable of the base class
	//Runs perfectly

}