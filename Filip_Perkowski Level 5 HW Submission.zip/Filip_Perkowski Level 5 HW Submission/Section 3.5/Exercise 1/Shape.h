#pragma once
#ifndef Shape_h
#define Shape_h

#include <iostream>
#include <sstream>
#include <string>

//Objective -> In this file we declare all the components within the Shape class
//Point, Line and Circle class must derive from the Shape class;

//In inheritance, a object of derived class has access to members of it's own class as well as the public members of the base class; The class that it inherits from;
//The base class does not have access to members of the classes that inherit from it

//Creating an object of derived class type will always invoke the appropriate constructor of the base class. If the derived class also contains the appropriate constructor then that constructor will be initiated as well
//Creating an object of base class type only the appropriate constructor from the base class will run this is done automatically as long as youv'e done [name of derived class] : base class in you .hpp or .cpp if you declare and define at once

class Shape {
private:
	int m_id;
public:
	Shape();
	Shape(int a);
	Shape(const Shape& c);
	~Shape();

	//ToString() Function
	virtual std::string ToString() const;

	//= operator function
	Shape& operator=(const Shape& c);

	//Get() Function
	int ID() const;

};


#endif