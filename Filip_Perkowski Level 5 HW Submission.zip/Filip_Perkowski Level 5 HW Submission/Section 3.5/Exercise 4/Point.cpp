#include <iostream>
#include <sstream>
#include <string>
#include <cmath>
#include "Point.h"

//Objective -> Our file here defines the contents of the Point Class

//Starting by defining our Point class constructors and deconstructor

namespace Filip {
	namespace CAD {
		Point::Point() : Shape(), m_x(0), m_y(0) { //Using the : syntax; Derived class constructor calls the base class constructor

		}

		Point::Point(double a, double b) : Shape(), m_x(a), m_y(b) {

		}


		Point::Point(const Point& c) : Shape(c), m_x(c.m_x), m_y(c.m_y) { 

		}

		Point::~Point() {
			//std::cout << "The Deconstructor!!" << std::endl;
		}

		//Our Get() Functions 
		double Point::X() const {
			return m_x;
		}

		double Point::Y() const {
			return m_y;
		}

		//Our Set() Function
		void Point::X(const double& a) {
			m_x = a;
		}

		void Point::Y(const double& b) {
			m_y = b;
		}

		std::string Point::ToString() const {
			std::stringstream a, b;
			a << "Point (" << m_x << "," << m_y << ")";
			return a.str();
		}

		//Draw() Function; Overwritting the Draw() pure virtual function from the Shape() class which is our base class
		void Point::Draw() const {
			std::cout << "Draw a Point!!" << std::endl;
		}

		//Our Distance() Functions
		double Point::Distance() const {
			return sqrt(pow(m_x - 0, 2) + pow(m_y - 0, 2));
		}

		double Point::Distance(const Point& p) const {
			return sqrt(pow(m_x - p.m_x, 2) + pow(m_y - p.m_y, 2));
		}


		//Our operator functions defined
		Point Point::operator-() const {
			Point c(-m_x, -m_y);
			return c;
		}

		Point Point::operator*(double factor) const {
			Point a(m_x * factor, m_y * factor);
			return a;
		}

		Point Point::operator+(const Point& p) const {
			Point a(m_x + p.m_x, m_y + p.m_y);
			return a;
		}


		bool Point::operator==(const Point& p) const {
			return m_x == p.m_x && m_y == p.m_y;
		}


		Point& Point::operator=(const Point& source) { //Last two operator functions shouldn't be const functions as we are changing the components of the underlying Line object that calls the opreator function
			if (this != &source) {
				m_x = source.m_x;
				m_y = source.m_y;
				return *this;
			}
			else {
				return *this;
			}

		}

		Point& Point::operator*=(double factor) {
			this->m_x = this->m_x * factor;
			this->m_y = this->m_y * factor;
			return *this;
		}

	}
}



//This operator << function is an outside function hence we don't have the Point:: access operator
std::ostream& operator <<(std::ostream& o, const Filip::CAD::Point& p) { //Use the << operator on a Point object and thanks to this function it gets allocated to cout for printing onto the console
	o << p.ToString(); //We can't fetch acess the m_y and m_x components of a Point object as the operator << function is not a public member of the Point class. Our only other option is to acess a public function
	return o;
}