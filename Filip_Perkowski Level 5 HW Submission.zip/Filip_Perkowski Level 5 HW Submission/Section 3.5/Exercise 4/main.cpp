#include "Shape.h"
#include "Point.h"
#include "Line.h"
#include "Circle.h"
#include <iostream>
#include <sstream>
#include <string>

//Abstract Class -> It's by definition a class that contains at least 1 pure virtual member function; Insantiate a class -> Means we can't create an object of that class type
//If classes that are dervied from an abstract class are not overwritten(contain they're own definition), they are also considered to be abstract classes as well
//You can think of a pure virtual function as a skeleton function in the base class, where we can overwrite it in each of our derived classes

//If you want your function to be overwriteable then you should include the virtual keyword

//As long as you markt the function in the base class as virtual; And include the = 0 to denote it as pure virtual if necessary then your'e fine; The function was already declared virtual in the base class we are just overwritting it wihtin the domain of the derived class

//Objective -> Testing all the classes;
//By including a pure virtual function in our Shape class(pure virtual function -> virtual function within no definition/body; So we only declare it in the .h files including the = 0 and that's it;) , our Shape class is now considered an abstract base class. Because of this we can't directly create objects of type Shape class


//Namespace Directive
using namespace Filip::CAD;

//We could use keyword override to make sure that we correctly override the Draw() function from the base class in each of the derived classes

//Creating an object of Shape class type is no possible given the pure virtual function. However, given that we have overitten the pure virtual function in our derived classes, we are able to create objects of Circle, Line, and Point class type freely
int main()
{
	
	Shape* shapes[10]; //This is an array called shapes which holds/elements of the array are -> 10 pointers to objects of Shape class. 
	shapes[0] = new Line; //0th index aka 1st element of array shapes is a object of class type Line
	shapes[1] = new Point;
	shapes[2] = new Circle;

	for (int i = 0; i != 3; i++) {
		shapes[i]->Draw();
	}
	
	for (int i = 0; i != 3; i++) {
		delete shapes[i];
	}
}